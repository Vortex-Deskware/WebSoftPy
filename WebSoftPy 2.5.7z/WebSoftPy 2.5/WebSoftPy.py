import sys
import shutil
import subprocess
from pathlib import Path
from PyQt6.QtCore import Qt, QUrl, QSize, QPoint
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QLineEdit, QPushButton, QCheckBox, QMessageBox, QGroupBox, QComboBox
)
from PyQt6.QtGui import QFont, QPalette, QColor, QIcon


def sanitize_filename(title: str) -> str:
    sanitized = title.lower().replace(' ', '_')
    return ''.join(c for c in sanitized if c.isalnum() or c == '_')


def copy_elements_to_webapps():
    script_dir = Path(__file__).parent.resolve()
    src_elements = script_dir / "elements"
    webapps_dir = script_dir / "webapps"
    dest_elements = webapps_dir / "elements"

    if not webapps_dir.exists():
        webapps_dir.mkdir(exist_ok=True)

    if src_elements.exists() and not dest_elements.exists():
        try:
            shutil.copytree(src_elements, dest_elements)
        except Exception as e:
            print(f"Warning: Could not copy elements folder: {e}")


def generate_webapp_script(title: str, url: str, use_persistent: bool, titlebar_mode: str, theme_name: str, filename: str):
    url = url.strip()

    webengine_core_imports = ["QWebEnginePage"]
    if use_persistent:
        webengine_core_imports.append("QWebEngineProfile")
    webengine_core_line = f"from PyQt6.QtWebEngineCore import {', '.join(webengine_core_imports)}"

    extra_imports = []
    if titlebar_mode.startswith("WebSoftPy"):
        extra_imports.extend([
            "from PyQt6.QtGui import QIcon, QFont",
            "from PyQt6.QtCore import QSize"
        ])

    base_imports = f"""import sys
from pathlib import Path
from PyQt6.QtCore import Qt, QPoint, QUrl{", QSize" if titlebar_mode.startswith("WebSoftPy") else ""}
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QPushButton, QLabel
)
from PyQt6.QtWebEngineWidgets import QWebEngineView
{webengine_core_line}"""

    if extra_imports:
        base_imports += "\n" + "\n".join(extra_imports)

    if use_persistent:
        storage_code = f'''
        from pathlib import Path
        profile = QWebEngineProfile("CustomProfile", self)
        profile.setPersistentCookiesPolicy(QWebEngineProfile.PersistentCookiesPolicy.ForcePersistentCookies)
        profile.setCachePath(str(Path.home() / ".{sanitize_filename(title)}" / "cache"))
        profile.setPersistentStoragePath(str(Path.home() / ".{sanitize_filename(title)}" / "storage"))
        page = QWebEnginePage(profile, self)
        self.webview.setPage(page)
'''
    else:
        storage_code = '''
        page = QWebEnginePage(self)
        self.webview.setPage(page)
'''

    if titlebar_mode == "normal":
        class_code = f'''
class SingleSiteBrowser(QMainWindow):
    def __init__(self, start_url: str, app_title: str):
        super().__init__()
        self.setWindowTitle(app_title)
        self.setMinimumSize(900, 600)

        self.webview = QWebEngineView()
{storage_code}
        self.webview.setUrl(QUrl(start_url))
        self.setCentralWidget(self.webview)
'''

    elif titlebar_mode.startswith("WebSoftPy"):
        class_code = f'''
class TitleBar(QWidget):
    def __init__(self, parent, app_title):
        super().__init__(parent)
        self.parent = parent
        self._drag_pos = QPoint()
        self.setFixedHeight(40)
        self.setStyleSheet("background-color: #2d2d2d; color: white;")
        layout = QHBoxLayout(self)
        layout.setContentsMargins(12, 0, 12, 0)

        title_label = QLabel(app_title)
        title_label.setFont(QFont("Segoe UI", 10, QFont.Weight.Bold))
        layout.addWidget(title_label)
        layout.addStretch()

        btn_size = 36
        btn_min = QPushButton()
        btn_min.setFixedSize(btn_size, btn_size)
        btn_min.setIcon(QIcon("elements/{theme_name}/minimize.svg"))
        btn_min.setIconSize(QSize(btn_size - 12, btn_size - 12))
        btn_min.clicked.connect(parent.showMinimized)

        self.btn_max = QPushButton()
        self.btn_max.setFixedSize(btn_size, btn_size)
        self.btn_max.setIcon(QIcon("elements/{theme_name}/maximize.svg"))
        self.btn_max.setIconSize(QSize(btn_size - 12, btn_size - 12))
        self.btn_max.clicked.connect(self.toggle_max_restore)

        btn_close = QPushButton()
        btn_close.setFixedSize(btn_size, btn_size)
        btn_close.setIcon(QIcon("elements/{theme_name}/close.svg"))
        btn_close.setIconSize(QSize(btn_size - 12, btn_size - 12))
        btn_close.clicked.connect(parent.close)

        for btn in (btn_min, self.btn_max, btn_close):
            btn.setStyleSheet("""
                QPushButton {{ background: transparent; border: none; }}
                QPushButton:hover {{ background: #444; border-radius: 6px; }}
            """)

        layout.addWidget(btn_min)
        layout.addWidget(self.btn_max)
        layout.addWidget(btn_close)

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self._drag_pos = event.globalPosition().toPoint()

    def mouseMoveEvent(self, event):
        if event.buttons() == Qt.MouseButton.LeftButton:
            diff = event.globalPosition().toPoint() - self._drag_pos
            self.parent.move(self.parent.pos() + diff)
            self._drag_pos = event.globalPosition().toPoint()

    def toggle_max_restore(self):
        if self.parent.isMaximized():
            self.parent.showNormal()
            self.btn_max.setIcon(QIcon("elements/{theme_name}/maximize.svg"))
        else:
            self.parent.showMaximized()
            self.btn_max.setIcon(QIcon("elements/{theme_name}/maximize.svg"))


class SingleSiteBrowser(QMainWindow):
    def __init__(self, start_url: str, app_title: str):
        super().__init__()
        self.setWindowFlags(Qt.WindowType.FramelessWindowHint)
        self.setMinimumSize(900, 600)

        self.webview = QWebEngineView()
{storage_code}
        self.webview.setUrl(QUrl(start_url))

        main_widget = QWidget()
        vbox = QVBoxLayout(main_widget)
        vbox.setContentsMargins(0, 0, 0, 0)
        vbox.setSpacing(0)
        vbox.addWidget(TitleBar(self, app_title))
        vbox.addWidget(self.webview)
        self.setCentralWidget(main_widget)
'''

    elif titlebar_mode == "frameless":
        class_code = f'''
class SingleSiteBrowser(QMainWindow):
    def __init__(self, start_url: str, app_title: str):
        super().__init__()
        self.setWindowFlags(Qt.WindowType.FramelessWindowHint)
        self.setMinimumSize(900, 600)

        self.webview = QWebEngineView()
{storage_code}
        self.webview.setUrl(QUrl(start_url))
        self.setCentralWidget(self.webview)

        self._drag_pos = QPoint()

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self._drag_pos = event.globalPosition().toPoint()

    def mouseMoveEvent(self, event):
        if event.buttons() == Qt.MouseButton.LeftButton:
            diff = event.globalPosition().toPoint() - self._drag_pos
            self.move(self.pos() + diff)
            self._drag_pos = event.globalPosition().toPoint()
'''

    else:
        raise ValueError("Invalid title bar mode")

    code = f'''{base_imports}

{class_code}

def main():
    app = QApplication(sys.argv)
    window = SingleSiteBrowser("{url}", "{title}")
    window.show()
    sys.exit(app.exec())

if __name__ == "__main__":
    main()
'''
    with open(filename, 'w', encoding='utf-8') as f:
        f.write(code.strip())


class WebSoftPyGUI(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("WebSoftPy 2.5")
        self.setFixedSize(620, 520)
        self.setStyleSheet("""
            QMainWindow { background-color: #1e1e1e; }
            QLabel { color: #f0f0f0; font-size: 13px; }
            QLineEdit {
                background: #2d2d2d;
                color: #f0f0f0;
                border: 1px solid #444;
                border-radius: 6px;
                padding: 8px;
                font-size: 13px;
            }
            QPushButton {
                background: #0d6efd;
                color: white;
                border: none;
                border-radius: 6px;
                padding: 10px;
                font-weight: bold;
                font-size: 13px;
            }
            QPushButton:hover { background: #0b5ed7; }
            QPushButton:disabled { background: #555; color: #aaa; }
            QCheckBox {
                color: #f0f0f0;
                spacing: 10px;
                font-size: 13px;
            }
            QCheckBox::indicator {
                width: 16px; height: 16px;
            }
            QCheckBox::indicator:unchecked {
                border: 1px solid #666; background: #2d2d2d;
            }
            QCheckBox::indicator:checked {
                background: #0d6efd; border: 1px solid #0d6efd;
            }
            QComboBox {
                background: #2d2d2d;
                color: #f0f0f0;
                border: 1px solid #444;
                border-radius: 6px;
                padding: 8px;
                font-size: 13px;
            }
        """)

        central = QWidget()
        layout = QVBoxLayout(central)
        layout.setSpacing(16)
        layout.setContentsMargins(28, 28, 28, 28)

        title_label = QLabel("WebSoftPy 2.5")
        title_label.setFont(QFont("Segoe UI", 18, QFont.Weight.Bold))
        title_label.setStyleSheet("color: #0d6efd; margin-bottom: 6px;")
        layout.addWidget(title_label)

        layout.addWidget(QLabel("Application Title"))
        self.title_input = QLineEdit()
        self.title_input.setPlaceholderText("e.g., My Web App")
        layout.addWidget(self.title_input)

        layout.addWidget(QLabel("Target URL"))
        self.url_input = QLineEdit()
        self.url_input.setPlaceholderText("https://example.com")
        layout.addWidget(self.url_input)

        # Title Bar Style
        layout.addWidget(QLabel("Window Style"))
        self.style_combo = QComboBox()
        self.style_combo.addItems([
            "Normal (Standard OS Title Bar)",
            "Custom Title Bar (Choose Theme Below)",
            "Frameless Window (No Controls)"
        ])
        self.style_combo.currentIndexChanged.connect(self.on_style_changed)
        layout.addWidget(self.style_combo)

        # Theme Selector (only visible for custom style)
        self.theme_label = QLabel("Theme")
        self.theme_combo = QComboBox()
        self.themes = [
            "WebSoftPy Flow",
            "WebSoftPy Desk",
            "WebSoftPy Color",
            "WebSoftPy Fizz",
            "WebSoftPy Text",
            "WebSoftPy Draw"
        ]
        self.theme_combo.addItems(self.themes)
        layout.addWidget(self.theme_label)
        layout.addWidget(self.theme_combo)

        # Info
        self.info_label = QLabel("")
        self.info_label.setWordWrap(True)
        self.info_label.setStyleSheet("font-size: 12px; color: #aaa; margin-top: 6px;")
        layout.addWidget(self.info_label)

        self.on_style_changed()  # Initialize visibility

        # Persistent Storage
        self.persist_check = QCheckBox("Enable Persistent Storage (cookies, cache, local data)")
        self.persist_check.setChecked(True)
        layout.addWidget(self.persist_check)

        # Buttons
        btn_layout = QHBoxLayout()
        self.gen_btn = QPushButton(" 💾 Generate Web App ")
        self.gen_btn.clicked.connect(self.generate)
        btn_layout.addWidget(self.gen_btn)

        self.build_btn = QPushButton(" 🛠️ Build Executable ")
        self.build_btn.clicked.connect(self.build_exe)
        self.build_btn.setEnabled(False)
        btn_layout.addWidget(self.build_btn)

        layout.addLayout(btn_layout)

        self.generated_script = None
        self.webapps_dir = Path("webapps").resolve()
        self.webapps_dir.mkdir(exist_ok=True)

        self.setCentralWidget(central)

    def on_style_changed(self):
        is_custom = self.style_combo.currentIndex() == 1
        self.theme_label.setVisible(is_custom)
        self.theme_combo.setVisible(is_custom)
        self.info_label.setVisible(True)

        if self.style_combo.currentIndex() == 0:
            self.info_label.setText("Uses the native operating system window frame. Fully standard behavior.")
        elif self.style_combo.currentIndex() == 1:
            self.info_label.setText("Custom frameless window with draggable title bar and theme-based SVG buttons.")
        else:
            self.info_label.setText("Completely borderless window. Drag anywhere to move. No system controls — user must close via task manager or Alt+F4.")

    def get_titlebar_mode(self):
        idx = self.style_combo.currentIndex()
        if idx == 0:
            return "normal"
        elif idx == 1:
            return self.theme_combo.currentText()
        else:
            return "frameless"

    def generate(self):
        title = self.title_input.text().strip()
        url = self.url_input.text().strip()
        titlebar_mode = self.get_titlebar_mode()
        theme_name = self.theme_combo.currentText() if self.style_combo.currentIndex() == 1 else ""

        if not title:
            QMessageBox.warning(self, "Input Missing", "Please enter an application title.")
            return
        if not url:
            QMessageBox.warning(self, "Input Missing", "Please enter a URL.")
            return
        if not url.startswith(("http://", "https://")):
            QMessageBox.warning(self, "Invalid URL", "URL must start with http:// or https://")
            return

        filename_base = sanitize_filename(title)
        if not filename_base:
            QMessageBox.warning(self, "Invalid Title", "Title must contain valid characters.")
            return

        script_path = self.webapps_dir / f"{filename_base}.py"
        use_persist = self.persist_check.isChecked()

        try:
            generate_webapp_script(title, url, use_persist, titlebar_mode, theme_name, script_path)
            self.generated_script = script_path
            self.build_btn.setEnabled(True)
            QMessageBox.information(self, "Success", f"Web app script generated!\n\n{script_path}")
        except Exception as e:
            QMessageBox.critical(self, "Generation Failed", f"Error:\n{str(e)}")

    def build_exe(self):
        if not self.generated_script or not self.generated_script.exists():
            return

        exe_name = self.generated_script.stem
        output_dir = self.webapps_dir

        reply = QMessageBox.question(
            self,
            "Build Executable?",
            f"Build standalone .exe for '{exe_name}'?\n\nThis may take 1–3 minutes.",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No
        )
        if reply != QMessageBox.StandardButton.Yes:
            return

        add_data_args = []
        if self.style_combo.currentIndex() == 1:
            if sys.platform.startswith('win'):
                add_data_args = ['--add-data', 'webapps/elements;elements']
            else:
                add_data_args = ['--add-data', 'webapps/elements:elements']

        try:
            cmd = [
                sys.executable, '-m', 'PyInstaller',
                '--onefile',
                '--windowed',
                '--name', exe_name,
                '--distpath', str(output_dir),
                '--hidden-import', 'PyQt6.QtWebEngineCore',
                '--hidden-import', 'PyQt6.QtNetwork',
                '--hidden-import', 'PyQt6.sip',
                '--hidden-import', 'PyQt6.QtSvgWidgets',
            ] + add_data_args + [str(self.generated_script)]

            subprocess.run(cmd, check=True)
            QMessageBox.information(
                self,
                "Build Complete",
                f"Executable created successfully!\n\nLocation:\n{output_dir / exe_name}"
            )
        except subprocess.CalledProcessError:
            QMessageBox.critical(self, "Build Failed", "PyInstaller build failed.")
        except FileNotFoundError:
            QMessageBox.critical(self, "Missing Dependency", "PyInstaller is not installed.\n\nRun: pip install pyinstaller")


if __name__ == "__main__":
    copy_elements_to_webapps()

    app = QApplication(sys.argv)

    dark_palette = QPalette()
    dark_palette.setColor(QPalette.ColorRole.Window, QColor(30, 30, 30))
    dark_palette.setColor(QPalette.ColorRole.WindowText, Qt.GlobalColor.white)
    dark_palette.setColor(QPalette.ColorRole.Base, QColor(25, 25, 25))
    dark_palette.setColor(QPalette.ColorRole.AlternateBase, QColor(53, 53, 53))
    dark_palette.setColor(QPalette.ColorRole.ToolTipBase, Qt.GlobalColor.white)
    dark_palette.setColor(QPalette.ColorRole.ToolTipText, Qt.GlobalColor.white)
    dark_palette.setColor(QPalette.ColorRole.Text, Qt.GlobalColor.white)
    dark_palette.setColor(QPalette.ColorRole.Button, QColor(70, 70, 70))
    dark_palette.setColor(QPalette.ColorRole.ButtonText, Qt.GlobalColor.white)
    dark_palette.setColor(QPalette.ColorRole.BrightText, Qt.GlobalColor.red)
    dark_palette.setColor(QPalette.ColorRole.Link, QColor(42, 130, 218))
    dark_palette.setColor(QPalette.ColorRole.Highlight, QColor(42, 130, 218))
    dark_palette.setColor(QPalette.ColorRole.HighlightedText, Qt.GlobalColor.black)
    app.setPalette(dark_palette)

    app.setStyleSheet("""
        QMessageBox { background-color: #2d2d2d; color: white; }
        QMessageBox QLabel { color: white; }
        QMessageBox QPushButton {
            background-color: #0d6efd;
            color: white;
            border-radius: 4px;
            padding: 6px 12px;
        }
        QMessageBox QPushButton:hover { background-color: #0b5ed7; }
    """)

    window = WebSoftPyGUI()
    window.show()
    sys.exit(app.exec())
