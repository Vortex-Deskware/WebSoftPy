Custom Title Bar Assets:

You can drag and drop your own SVG files into any theme folder to customize the appearance of the title bar controls in "Custom" mode.

To ensure compatibility, keep the original filenames. To Refresh the /elements folder inside /webapps , delete it and run the script again.

Feel free to edit or replace these files with your own designs. The application will automatically use your versions at runtime.