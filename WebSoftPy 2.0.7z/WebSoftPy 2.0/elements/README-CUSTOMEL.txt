Custom Title Bar Assets:

You can drag and drop your own SVG files into this folder to customize the appearance of the title bar controls in "WebSoftPy Flow" mode.

To ensure compatibility, keep the original filenames.

Feel free to edit or replace these files with your own designs. The application will automatically use your versions at runtime.